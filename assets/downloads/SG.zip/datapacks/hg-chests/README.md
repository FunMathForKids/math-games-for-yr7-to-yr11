# hello
visit https://l.plexion.dev/survivalgames for the actual download
and licensing info for this datapack.

thanks!